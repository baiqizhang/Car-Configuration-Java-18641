package com.baiqiz.project1.adapter;

import com.baiqiz.project1.exception.AutoException;

public interface FixAuto {
	public String FixError(AutoException e);
}
