package com.baiqiz.project1.adapter;

public class BuildAuto 
	extends ProxyAutomotive 
	implements CreateAuto, UpdateAuto, FixAuto, PickAuto
{
}
