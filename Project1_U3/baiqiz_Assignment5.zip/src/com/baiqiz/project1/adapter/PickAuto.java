package com.baiqiz.project1.adapter;

public interface PickAuto {
	public void pickOption(String Modelname, String optionSetName, String
			optionName);
	public float getTotalPrice(String Modelname);
}
