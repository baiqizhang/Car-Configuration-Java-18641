package com.baiqiz.project1.adapter;

public interface CreateAuto {
	public void BuildAuto(String filename);
	public void PrintAuto(String modelname);
}
